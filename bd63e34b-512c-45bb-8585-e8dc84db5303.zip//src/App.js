import React, { useState } from "react";
import { motion } from "framer-motion";

// Sample data
const productsData = [
  {
    id: 1,
    name: "Bayam Segar",
    category: "sayur",
    img: "https://via.placeholder.com/300",
    desc: "Bayam hijau segar langsung dari kebun.",
    stock: true,
  },
  {
    id: 2,
    name: "Kunyit",
    category: "rempah",
    img: "https://via.placeholder.com/300",
    desc: "Kunyit organik untuk bumbu masakan.",
    stock: true,
  },
  {
    id: 3,
    name: "Ikan Lele",
    category: "ikan",
    img: "https://via.placeholder.com/300",
    desc: "Ikan lele segar siap olah.",
    stock: false,
  },
];

export default function App() {
  const [page, setPage] = useState("home");
  const [search, setSearch] = useState("");

  const filteredProducts = productsData.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-green-50 text-gray-800">
      {/* Navbar */}
      <nav className="flex justify-between p-4 bg-green-600 text-white">
        <h1 className="text-xl font-bold">Toko Sayur Segar</h1>
        <div className="flex gap-4">
          <button onClick={() => setPage("home")}>Home</button>
          <button onClick={() => setPage("produk")}>Produk</button>
          <button onClick={() => setPage("about")}>Tentang Kami</button>
        </div>
      </nav>

      {/* Home */}
      {page === "home" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="p-6 text-center"
        >
          <h2 className="text-3xl font-bold mb-4">
            Selamat Datang di Toko Sayur Segar
          </h2>
          <p className="text-lg">
            Kami menyediakan sayur, rempah, ikan & daging segar setiap hari.
          </p>
        </motion.div>
      )}

      {/* Produk */}
      {page === "produk" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="p-6"
        >
          <h2 className="text-2xl font-bold mb-4">Daftar Produk</h2>

          {/* Search */}
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari produk..."
            className="p-2 border w-full rounded mb-4"
          />

          {/* Product Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {filteredProducts.map((p) => (
              <div key={p.id} className="bg-white p-4 rounded-xl shadow">
                <img src={p.img} className="w-full rounded-xl mb-2" />
                <h3 className="font-bold text-lg">{p.name}</h3>
                <p className="text-sm mb-2">{p.desc}</p>
                <p className={p.stock ? "text-green-600" : "text-red-600"}>
                  {p.stock ? "Stok Tersedia" : "Stok Habis"}
                </p>
                <a
                  href="https://wa.me/6280000000000"
                  target="_blank"
                  className="block mt-3 bg-green-600 text-white p-2 rounded-xl text-center"
                >
                  Pesan via WhatsApp
                </a>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* About */}
      {page === "about" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="p-6 text-center"
        >
          <h2 className="text-2xl font-bold mb-4">Tentang Kami</h2>
          <p className="mb-4">
            Toko Sayur Segar adalah usaha yang menyediakan bahan makanan segar
            dan berkualitas.
          </p>
          <p>Instagram: @tokosayur</p>
          <p>WhatsApp: 0800-0000-0000</p>
        </motion.div>
      )}
    </div>
  );
}
